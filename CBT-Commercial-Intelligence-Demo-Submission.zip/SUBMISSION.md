# CBT Commercial Intelligence Demo — Submission Notes

## Project purpose

An interactive prototype demonstrating how CBT / Chinaberry Tree Hospitality Supply could review historical sales, customer trends, product performance, inventory needs, purchase planning, orders, receivables, and alerts in one role-based web app.

## Live demo

https://cbt-commercial-intelligence-demo.davidleekarma.chatgpt.site/

## Demo highlights

- Four role views: Owner / General Manager, Sales Manager, Sales Rep, and Purchasing / Inventory.
- Sales history and forecast presentation, sample customer segmentation and growth / decline analysis, first-purchase dates, churn risk, SKU performance, aging-stock alerts, seasonal inventory planning, and sample purchase suggestions.
- Date-range controls (YTD, last quarter, last month, last year, and custom range) for customer, product, and inventory analysis.
- Filter and ascending / descending sort menus on every data table column. Table widths, order, and sidebar width can be adjusted.
- Simulated WooCommerce order intake and QuickBooks Online reconciliation entry points.

## Open the demo

1. Extract the ZIP file.
2. Open `index.html` in a current desktop browser (Chrome or Edge recommended).
3. Use the left navigation and role selector to explore the demo. Select `Layout` to reset saved layout changes.

The demo is a standalone HTML file and has no installation step. The official CBT logo is bundled locally. Internet access is only needed for optional web fonts; local system fonts remain available offline.

## Data and limitations

All 2016–2026 sales history, customer, SKU, inventory, order, supplier, and financial values are generated sample data. They are clearly identified in the app and are not CBT business records. The prototype does not connect to WooCommerce, QuickBooks Online, or any live system, and it does not modify Excel workbooks. Forecasts, reorder quantities, risks, and comparisons are illustrative and are not for operational purchasing or financial decisions. Commission calculation is outside this first phase; the customer first-purchase date is retained.

## Branding

The CBT logo is referenced from the company's public website. Company website: https://cbthospitalitysupplies.com/ (formerly cbtlinens.com).


