# Branding asset note

The CBT logo is bundled locally as `cbt-logo.jpg`, sourced from CBT's public website: https://cbthospitalitysupplies.com/ (formerly cbtlinens.com). The demo does not need a network connection to load the logo.
