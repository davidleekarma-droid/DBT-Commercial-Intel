# CBT Commercial Intelligence Demo

An interactive, English-language demo for CBT / Chinaberry Tree Hospitality Supply. Every customer, order, inventory, financial metric, and 2016–2026 sales figure is generated sample data. It is not representative of CBT's actual business. Only the annual folder structure under `Sales Details and Analysis` was referenced; Excel contents were not read or modified.

## Run locally

1. Extract the ZIP file to a folder. Keep **index.html** and **cbt-logo.jpg** together in that folder.
2. Double-click **index.html** to open the demo in Chrome, Edge, or another current browser. No installation is required.
3. If your browser restricts local files, open PowerShell in the extracted folder and run:

    python -m http.server 8765

Then open http://localhost:8765. Press Ctrl+C to stop the local server.
## Suggested demo walkthrough

1. Use the role selector at the top right to switch among Owner / General Manager, Sales Manager, Sales Rep, and Purchasing / Inventory. Each role has a different dashboard emphasis and navigation permissions.
2. Start at Executive Overview to show the sales forecast, reorder reminders, inventory risks, and latest orders.
3. Open Sales Trends & Forecast to explain the ten-year sample history and the forecast assumptions. Year and period filters are clickable.
4. Open Customer Insights to review 30 sample accounts ranked by current sales. For each customer, compare current sales with the prior-year period and the prior three-year average in both dollars and percent. Filter by segment, search accounts, and review first purchase date, owner, reorder cycle, and churn risk. Select View account for a follow-up brief. The Sales Rep role is scoped to Alex Chen's accounts. On narrow screens, scroll the comparison table horizontally to see all columns.
5. Open Products & SKUs to compare current revenue and units sold with the prior year and prior three-year averages. The action column flags revenue/unit declines and stock aged over 180 days for promotion review. Select View action for a SKU brief, or search by SKU and filter by category. Scroll the table horizontally on narrow screens to view comparison and action columns.
6. Switch to Purchasing / Inventory (which opens directly to the purchase plan). For each SKU, compare November, December, and January actual units sold in 2023, 2024, and 2025; review each month's three-year average; then review the November 2026, December 2026, and January 2027 forecasts. Current stock, supplier lead time, lead-time demand, three-month forecast demand, and an editable suggested order quantity appear on the same row.
7. In Order Management, select New online order and create a sample order. It remains in the current page session and disappears on refresh; it does not call an external system.
8. Show the QuickBooks Online entry point and receivables aging. Integration actions are simulated.
9. Open Alerts Center and filter by high, medium, or low priority. It includes account sales declines and SKU decline / aging alerts with specific comparison details and thresholds.

## Layout controls

- Drag the thin divider next to the left navigation to make the sidebar narrower or wider. The desktop width is remembered in the browser.
- Drag a table column's right edge to resize it.
- Drag a column header to move it, including to the far right. Each table remembers its own column widths and order in the browser.
- Select **Layout** in the top bar to restore the default sidebar width and table layouts.
- On smaller screens, wide tables remain horizontally scrollable; use the table's horizontal scrollbar to reach columns outside the visible area.

## Customer, product, and inventory analysis controls

- Each of these three pages has the same date range bar: **YTD**, **Last quarter**, **Last month**, **Last year**, and **Custom**. Custom dates use the two date pickers and **Apply dates** button.
- The displayed range is shown beside the controls. Customer and product sales comparisons update to the selected range and compare with generated matching-period baselines. Inventory shows units sold within the selected range; the seasonal November–January purchase planner remains visible for planning.
- Select the small **▾** control in any table column heading to filter that column by text or value, sort the table ascending or descending by that column, or clear its filter. Filters and sort choices are remembered per table in that browser.
- All values remain generated sample data. Custom ranges outside 2016–2026 are illustrative extrapolations and should not be used as operational forecasts.

## Demo model assumptions

- Customer risk is illustrative: high risk is a score of 65 or more, with a primary signal when time since last purchase exceeds 1.2 times the average reorder cycle; watch is 40–64; healthy is below 40.
- The sample low-stock alert fires when on-hand inventory is below safety stock. Sample safety stock represents about 45 days of demand. Stockout timing also considers days of supply and supplier lead time.
- The illustrative slow-moving rule is no sales in 90 days and inventory value above $2,500. The SKU table also displays inventory age.
- SKU monthly history and the November/December/January seasonality profiles in the table are generated sample data. Monthly forecasts weight the matching month 20% / 30% / 50% toward 2023 / 2024 / 2025, then apply a modest trend adjustment. Values are illustrative, not for purchasing decisions.
- The table shows both three-month demand and estimated demand during supplier lead time. The editable sample order quantity is the three-month forecast plus a small ending-stock buffer, less current on-hand inventory; the demo assumes zero confirmed inbound units. An operational reorder calculation should use the actual order and arrival dates, inbound stock, supplier minimum order quantities, case packs, and a chosen safety-stock policy.
- First purchase date is retained for customer lifecycle analysis. Commission calculations are out of scope for Phase 1.
- The demo includes 30 generated sample customer accounts. Customer dollar and percent comparisons use generated prior-year and three-year baseline values; replace these with the actual comparable period totals before using the analysis for decisions.
- Product revenue and unit comparisons also use generated sample baselines. Product alerts fire at a decline of 15% year over year or 20% versus the prior three-year average. Inventory older than 180 days is flagged for promotion or clearance review.

## Pages

Executive Overview, Sales Trends & Forecast, Customer Insights, Products & SKUs, Inventory & Purchasing, Order Management, Accounts Receivable, Alerts Center, and Data Connections. The layout supports desktop and narrow screens.

