# 作业提交说明｜CBT Commercial Intelligence Demo

## 推荐提交方式

1. 下载并解压 CBT-Commercial-Intelligence-Demo-Submission.zip。
2. 如果学校的提交系统允许 ZIP，直接上传这个 ZIP 即可，里面已包含 Demo、Logo 和所有说明文件。
3. 如果必须提交网页文件，请把解压后的整个文件夹上传，确保 index.html 与 cbt-logo.jpg 一起保留。
4. 如果老师只需要查看演示，也可以提交在线链接：
   https://cbt-commercial-intelligence-demo.davidleekarma.chatgpt.site/

## 如何在电脑上打开

解压 ZIP 后，双击 index.html。建议使用 Chrome 或 Edge。无需安装软件。Logo 已随包保存。如果浏览器限制本地文件，请查看英文 README 的本地服务器备用方法。

## 文件清单

- index.html：完整的英文可交互网页 Demo。
- cbt-logo.jpg：随包附带的 CBT Logo。请不要从网页文件夹中单独移走。
- README.md：英文完整使用指南、演示讲解顺序和模拟数据说明。
- SUBMISSION.md：项目目的、功能亮点、数据范围和限制。
- LOGO-NOTICE.md：Logo 来源说明。

## 数据说明

客户、销售、产品、库存、订单和财务数字均为模拟样例，不是真实 CBT 业务数据。Demo 不连接 WooCommerce 或 QuickBooks Online，也不会修改本地 Excel 文件。
